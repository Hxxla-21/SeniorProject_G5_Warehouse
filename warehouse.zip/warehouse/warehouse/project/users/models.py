from django.db import models
from django.utils import timezone
from django.utils.translation import activate
from django.contrib.auth.models import User
from django.utils.text import slugify
from django.db.models.signals import post_save

class Profile(models.Model):

    CENDER = {
        ('Male' , 'Male'),
        ('Female' , 'Female')
    }
    user         = models.OneToOneField(User , on_delete=models.CASCADE)
    name         = models.CharField(max_length=265)
    phone        = models.CharField(max_length=50)
    mobile       = models.CharField(max_length=50)
    jop          = models.CharField(max_length=50)

    bio          = models.TextField()
    country      = models.CharField(max_length=300)
    address      = models.CharField(max_length=265)
    wibsite      = models.URLField()
    cender       = models.CharField(choices=CENDER, default='Male' , max_length=50)
    date_of_birth = models.DateTimeField(default=timezone.now )
    
    website      = models.CharField( max_length=200)
    facebook     = models.CharField( max_length=200)
    twitter      = models.CharField( max_length=200)
    instagram    = models.CharField( max_length=200 , blank=True , null=True)
    slug         = models.CharField(max_length=20, blank=True , null=True)

    activate =                  models.BooleanField(default=False)

    def save(self , *args, **kwargs):
        if not self.slug :
            self.slug = slugify(self.user.username)
        super(Profile , self).save( *args, **kwargs)

    def __str__(self):
        return str(self.user.username )


def create_profile(sender , **kwargs):
    if kwargs['created'] :
        user_profile = Profile.objects.create(user=kwargs['instance'])

post_save.connect(create_profile , sender=User)