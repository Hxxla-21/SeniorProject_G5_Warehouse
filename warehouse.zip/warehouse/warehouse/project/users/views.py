from django.shortcuts import redirect, render
from .models import Profile
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate , login
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from .forms import LoginForm



def profile_detail(request , slug):
    query = Profile.objects.get(slug = slug )
    return render(request , 'profile_detail.html' , {'query' : query})


def user_signup(request):
    if request.method =='POST' :
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = request.POST['username']
            password = request.POST['password2']
            user = authenticate(request , username=username , password=password)
            if user is not None:
                login(request , user)
    else:
        form = UserCreationForm()
    return render(request , 'signup.html' ,  {
    'form' : form ,
    })

def user_login(request):
    
    if request.method == 'POST':
        form = LoginForm()
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username , password=password)
        if user is not None :
            login(request , user)
            
    else:
        form = LoginForm()
    return render(request , 'login.html' ,  {
        'form' : form , 
    })

def logout(request):
    auth.logout(request)
    return redirect('ad:ads')