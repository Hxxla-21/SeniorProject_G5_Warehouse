from django.urls import path
from .views import *

app_name = 'users'

urlpatterns = [
    path('signup/' , user_signup , name='signup'),
    path('profile/<str:slug>/' , profile_detail , name='profile_detail'),
    path('login/' , user_login , name='login'),
    path('logout/' , logout , name='logout'),
]
