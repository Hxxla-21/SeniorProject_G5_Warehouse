<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    
    // using concat mysql function
    $query = "SELECT * FROM `products` WHERE CONCAT(`CAT`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `products`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "WH_db");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>




<!DOCTYPE html>
<head>

<meta charset="UTF-8" />
<link rel="stylesheet" href="Style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

<title> Products </title>

</head>



<header>
   
    
</header>

<body>

<!-- Modal popup -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel"> Fill Request Form </h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form action="Requests.php" method= "POST">

          <div class="modal-body">
           
           <div class="form-group">
           <label> IRB number</label>
           <input type="text" name="IRB" class="form-control" placeholder="Enter IRB number">
           </div>

           <div class="form-group">
           <label> Project ID</label>
           <input type="number" name="projectId" class="form-control" placeholder="Enter project ID">
           </div>

           <div class="form-group">
           <label>Needed Quantity </label>
           <input type="number" name="quantity" class="form-control" placeholder="Enter needed quantity">
           </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="sendRequest" class="btn btn-primary">Send request</button>
      </div>

      </form>
    </div>
  </div>
</div>
<form  class = "container" action="Products.php" method="POST"> 

    <div class="card">
    <div><br><br><input type="text" name="valueToSearch" placeholder=" Enter #CAT number to search "><br></div>
    <div><button type="submit" name="search"class="btn btn-outline-success">Filter</button><br><br></div>
    </div>
    <table class="table table-striped table-hover">
        <tr>
            <th> Description</th> 
            <th> Quantity on hand </th>
            <th>CAT#</th>
            <th>UMO</th>
            <th> - </th>    
        </tr>
    


<!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['Description'];?></td>
                    <td><?php echo $row['QuantityOnHand'];?></td>
                    <td><?php echo $row['CAT'];?></td>
                    <td><?php echo $row['UMO'];?></td>
                    <td> <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"> Request</button></td>
                </tr>
                <?php endwhile;?>
            </table>   
        </form>






       <script src=" https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
       <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
       <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>   
    </body>
</html>