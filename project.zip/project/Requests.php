<?php
 $connect = mysqli_connect("localhost", "root", "", "WH_db");
 
 if(isset($_POST['sendRequest'])){

    $IRB = $_POST['IRB'];
    $projectId = $_POST['projectId'];
    $quantity = $_POST['quantity'];
    
    $query ="INSERT INTO request (`IRB`, `ProjectID`, `Needed_Quantity`) VALUES ('$IRB','$projectId','$quantity')";
    $query_run = mysqli_query($connect,$query);

    if ($query_run) 
    {
        echo '<script> alert("Request Sended");</script>';
        header('Location: Products.php');
    }
    else { echo '<script> alert("Request Not Sended"); </script>';}
 }

 ?>


<!DOCTYPE html>
<head>

<meta charset="UTF-8" />
<title> Home page </title>
<link rel="stylesheet" href="Style.css">
</head>
   